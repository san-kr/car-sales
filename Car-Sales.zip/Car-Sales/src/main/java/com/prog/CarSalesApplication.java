package com.prog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarSalesApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarSalesApplication.class, args);
	}

}
